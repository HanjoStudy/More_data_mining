#############################################
#####   READING and WRITING FILES in R  #####
#####      DATA INPUT and OUTPUT        #####
#############################################

# Must install a package first time you use it
# For example:

#install.packages("xlsx")
#install.packages("reshape2")
#install.packages("ggplot2")
#install.packages("GGally")
#install.packages("vcd")

# library similar to require()
library("foreign")

# require() used within functions often
# as it will not cause an error if package
# is not installed
require("reshape2")
require("ggplot2")
# Note quote marks not strictly needed
# but a good idea to be consistent
require(GGally)
require(vcd)

# Provides print version information about
# your R session and attached or loaded packages
sessionInfo()

# Gives the search path for R objects
# Gives a list of attached packages (library() command)
# and R objects, usually data.frames
search()

# assign the number 3 to object called abc
abc <- 3
# list all objects in current session
ls()

# comma separated values
dat.csv <- read.csv("http://www.ats.ucla.edu/stat/data/hsb2.csv")
# tab separated values use read.table()
dat.tab <- read.table("http://www.ats.ucla.edu/stat/data/hsb2.txt",
  header=TRUE)#, sep = "\t")
# file.choose() opens up a windows browser to
# drill down and select a file
my.file <- read.csv(file.choose())

# foreign is a package that allows you to directly
# import spss and other proprietary file types
require(foreign)
# SPSS files
dat.spss <- read.spss("http://www.ats.ucla.edu/stat/data/hsb2.sav",
  to.data.frame=TRUE)
# Stata files
dat.dta <- read.dta("http://www.ats.ucla.edu/stat/data/hsb2.dta")

# first six rows
head(dat.csv)
# last six rows
tail(dat.csv)
# variable names
colnames(dat.csv)
# pop-up view of entire data set
View(dat.csv)
#or to show in console
dat.csv

# single cell value
dat.csv[2,3]
# omitting row value implies all rows; here all rows in column 3
dat.csv[,3]
# omitting column values implies all columns; here all columns in row 2
dat.csv[2,]
# can also use ranges - rows 2 and 3, columns 2 and 3
dat.csv[2:3, 2:3]

# get first 10 rows of variable female using two methods
dat.csv[1:10, "female"]
dat.csv$female[1:10]

# get column 1 for rows 1, 3 and 5
dat.csv[c(1,3,5), 1]
# get row 1 values for variables female, prog and socst
dat.csv[1,c("female", "prog", "socst")]

colnames(dat.csv) <- c("ID", "Sex", "Ethnicity", "SES", "SchoolType",
  "Program", "Reading", "Writing", "Math", "Science", "SocialStudies")

# to change one variable name, just use indexing
colnames(dat.csv)[1] <- "ID2"

#write.csv(dat.csv, file = "path/to/save/filename.csv")

#write.table(dat.csv, file = "path/to/save/filename.txt", sep = "\t", na=".")

d <- read.csv("http://www.ats.ucla.edu/stat/data/hsb2.csv")

# gives dimensions in rows and columns
dim(d)
# shows structure, very useful
str(d)

# numeric summary of each variable
summary(d)

# some ggplot graphics
ggplot(d, aes(x = write)) + geom_histogram()
ggplot(d, aes(x = write)) + geom_density()
ggplot(d, aes(x = 1, y = math)) + geom_boxplot()

# density plots by program type
ggplot(d, aes(x = write)) + geom_density() + facet_wrap(~ prog)
ggplot(d, aes(x = factor(prog), y = math)) + geom_boxplot()
# melt is a reshape function
ggplot(melt(d[, 7:11]), aes(x = variable, y = value)) + geom_boxplot()
ggplot(melt(d[, 6:11], id.vars = "prog"),
       aes(x = variable, y = value, fill = factor(prog))) +
  geom_boxplot()

# load lattice
require(lattice)

# simple scatter plot
xyplot(read ~ write, data = d)

# conditioned scatter plot
xyplot(read ~ write | prog, data = d)

# conditioning on two variables
xyplot(read ~ write | prog * schtyp, data = d)

# box and whisker plots
bwplot(read ~ factor(prog), data = d)

# cross tabulation
xtabs( ~ female, data = d)
xtabs( ~ race, data = d)
xtabs( ~ prog, data = d)
xtabs( ~ ses + schtyp, data = d)

# create some tables to plot
(tab3 <- xtabs( ~ ses + prog + schtyp, data = d))

(tab2 <- xtabs( ~ ses + schtyp, data = d))
# setting seed gives you same result each time
set.seed(10)
(testtab2 <- coindep_test(tab2, n = 5000))

# simple mosaic plot, areas are proportional
mosaic(tab2)
mosaic(tab2, gp = shading_hsv,
  gp_args = list(p.value = testtab2$p.value, interpolate = -1:2))

cotabplot(~ ses + prog | schtyp, data = d, panel = cotab_coindep, n = 5000)
# correlation
cor(d[, 7:11])
# help is ?
?cor
# no missing data
cor(d[, 7:11], use = "complete.obs")
# only pairs that are complete
cor(d[, 7:11], use = "pairwise.complete.obs")
# ggpairs plots a scatterplot matrix
ggpairs(d[, 7:11])

###########################################
#####   MORE DATA INPUT AND OUTPUT    #####
###########################################

## Are many ways to input and output data in R 
## Here we look at several of most used commands
## Is not exhaustive, would take days.
## for input and output, dividing it up into
## 1) interactively (keyboard); 
## 2) file input / output; and
## 3) accessing data in packages.

###########################################
## 1) Keyboard Input: scan(); readline().

## Useful if number of values is small
## Can use scan() function
## scan() can also input files
## Interactive keyboard input ot useful for large data sets

x <- scan()
x

## scan() can read data from a file
## scan() reads a vector of values.
## scan() also returns a vector of values.

## General form of scan():

## scan(file="", what=0, n= -1, sep="", skip=0, quiet=FALSE)

## all arguments are optional. Defaults:
## file: file to read from; "" (nothing) is keyboard
## what: example of mode of data;
## what: 0 default numeric; " " for character
## n: number elements to read; n = -1 is to end of file
## sep: character to separate values; "" means 'any'
## skip: # lines to skip before read, default is 0 # for example, have descriptive text on top
## quiet: whether scan() reports number values read (F is default)

## Example reading in string (character) data

names <- scan(what=" ")


# 1: jeff linda
# 3: irving mary bill
# 6: louis
# 7: 
#   Read 6 items
# > names
# [1] "jeff"   "linda"  "irving" "mary"   "bill"   "louis" 
# > mode(names)

## 'scan.txt' contains

# 12 bobby
# 24 kate
# 35 david
# 20 michael

## Importing data files using the scan() function
## The scan() function is an extremely flexible 
## tool for importing data.  Unlike the read.table() 
## function, however, which returns a data frame, 
## the scan() function returns a list or a vector.   

# changes input to a list of age and name
x <- scan("c:/temp/scan.txt", what=list(age=0, name=""))

# Read 4 records

x

# $age
# [1] 12 24 35 20

# $name
# [1] "bobby"   "kate"    "david"   "michael"

# using the same text file and saving only the names as a vector
x <- scan("c:/temp/scan.txt", what=list(NULL, name=character()))

# Read 4 records

x # is a list, first component is null

unlist(x) # gets rid of first null component
# what reamins is a named vector

x # but x is unchanged, unless we do:

x <- unlist(x)
x

## Can look and see what is in a directory

list.files(path = "c:/temp") # to list files in any directory

## To read a file into memory using scan():
## assuming that the file 'file_name' is numeric

## Here is a trick:
file_name = "c://temp/data1.txt"
file_name

# Read from file using scan
d1 <- scan(file = file_name)
d1

## Or can name (numeric) file directly:

d <- scan(file = "c://temp//data.txt")
d

## Can also use readline() function to read
## a line from keyboard interactively
## readline(prompt = "")

readline(prompt = "What do you like the most about R?: ")

## Couple it with an assignment:

what.I.like <- readline(prompt = "What do you like the most about R?: ")
what.I.like

#########################################################
## 2) File Input and Output: read.table(); and read.csv().

## Tabular Data Input directly from a file
## Most used functions are read.table() and read.csv()
## read.table expects a text file and converts to data frame

## If you Want to see files in a certain directory:

list.files("c:/temp")
read.table("c://temp/daphnia.txt", header = T)

## Couple with assignment and put into parentheses (to print):
(daphnia.data <- read.table("c://temp/daphnia.txt", header = T))

## To see what default directory is:
getwd()

## To change it to c:/temp (or any other directory):
setwd("c://temp")

## To verify what directory is now:
getwd()

## list.files is non-interactive:
list.files()

## file.choose() coupled with read.table() is interactive:
chosen.txt <- read.table(file.choose(), header = T)
chosen.txt
head(chosen.txt) # just first six rows

## What is class of chosen.file ?
class(chosen.txt)

## read.table() and read.csv() change input to dataframe

## read.csv() expects a csv file
chosen.csv <- read.csv(file.choose())
head(chosen.csv)

## What is class of chosen.csv ?
class(chosen.csv)

####################    OUTPUT: WRITING TO FILES

## Most used functions to write data to output files 
## are write.table() and write.csv() to output 
## data frame into a plain text files
write.csv(chosen.csv, "geoff.csv")
list.files()
file.exists("geoff.csv")

write.table(chosen.txt, "geoff.txt")
file.exists("geoff.txt")

## 3) Accessing Data in R Packages
## Many packages contain data sets
## Two approaches to access data in packages:
## Generally, (not always) must first
## load package using library() command.
## (Package must be installed first always).

## Then use either: 1) data(); or 2) attach() commands

## First load the package
library(car)

## A data set can be read into global environment using data() command
data(Prestige)
ls()

## Or by referencing the package if not loaded
data(clouds, package = "HSAUR2")
ls()

## To see data in particular packages
data(package="HSAUR2")

## Data sets in packages are loaded as data frames

## Other way is to use attach() command
## Attaching makes a copy of the data frame
search()
library("HSAUR2")
attach(Forbes2000)
search()    # Note that Forbes2000 is now #2 in search path

detach(Forbes2000)
search()

str(heptathlon)
plot(run200m,run800m)
plot(heptathlon$run200m,heptathlon$run800m)
